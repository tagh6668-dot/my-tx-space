
------------------------------------------------------------------------
          Package to capture and analyze network traffic
                    to improve voice quality
                   for 7905/7912 IP Phones and
              ATA 186/188 Analog Telephone Adaptors
                             README
                          February 2004
------------------------------------------------------------------------

(c) Copyright Cisco Systems, 2004


Summary
=======

This software package is intended to help identify potential network
problems, which result in degraded conversation quality while using
Cisco 7905/7912 IP Phones or ATA 186/188 Analog Telephone Adaptors. It
detects temporary peaks of network traffic, such as multicast and
broadcast, and captures it for the subsequent analysis. Unlike popular
packet sniffer programs, it doesn't save the entire traffic, but only
the temporary peaks, by constantly monitoring the bandwidth within the
short-time sliding window.

The package contains required WinPcap packet capture driver (also
available freely at http://winpcap.polito.it). The peak traffic,
captured in a  file, can be viewed and analyzed by Ethereal - a network
protocol analyzer, available at http://www.ethereal.com.

Identified traffic peaks usually point out to the source of heavy
traffic, which needs to be reconfigured, isolated to a separate network
or taken offline.


Package Content
===============

The nptcap.zip file contains the following files:

 - WinPcap packet capture driver WinPcap_3_1_beta.exe (self installer).
   It is necessary to install this driver first in order to be able to
   capture any network traffic;

 - nptcap.exe - the main executable for Win32 platform;

 - this readme.txt file.


Network Topology
================

Nptcap needs to be installed on a Win32 machine with at least one
working Ethernet adapter. The adapter has to be plugged in to the same
switch port as the IP Phone or ATA under investigation. This can be done
by plugging both a PC and IP Phone/ATA to the same hub, also plugged to
the main uplink switch.


Installation Procedure
======================

 - unzip the nptcap.zip content to any directory, for example:
   C:\Program Files\Cisco Systems\nptcap;

 - install WinPcap packet capture driver by running the self installer
   called WinPcap_3_1_beta.exe;

 - nptcap.exe does not require a special installation procedure and can
   be executed from the Command Prompt window


Running Nptcap
==============

 - open Command Prompt window (MS-DOS Prompt on Windows 9x, ME
   platforms);
 - change current directory to where you extracted the nptcap.zip
   content, for example:
   cd "C:\Program Files\Cisco Systems\nptcap"
 - run nptcap program.

If everything is ok, you should see the message similar to this:
 
   Listening on Network adapter 'Intel(R) PRO Adapter' on local host...

This means, your machine has only one network interface and nptcap has
started to listen on it using all the default parameters. If there are
several network interfaces, nptcap will display a numbered list and
exit. You need to select interface from the list using "-i number"
command line argument.

If the network traffic reaches or exceeds the threshold value, it will
be captured by nptcap to a file. The following message will be
displayed:

   Saving 2004-02-17_12h11m37s_1532kbps.cap... done

It means the *.cap file has been saved to the current directory. The
filename contains current timestamp and network bandwidth. The program
will keep running until maximum number of files were created or Ctrl-C
is pressed.


Command Line Syntax, Parameters and Default Values
==================================================

The following help screen can be displayed by using "nptcap -h" command:

nptcap [-h] [-i number] [-b bandwidth] [-f "filtering expression"]
       [-w length] [-n number]

  -i   Interface to listen on. List is displayed, when option not
       specified
  -b   Bandwidth threshold value, kbps, default: 1500
  -f   Filtering expression, default:
       "ether broadcast or ether multicast"
       For expression syntax: http://www.tcpdump.org/tcpdump_man.html
  -w   Capture window length, seconds, default: 1
  -n   Max number of capture files to create, default: 1000

If no parameters are specified, nptcap will use 1500 kbps (1.5 Mbps)
bandwidth threshold and 1 second sliding window. It will be capturing
all Ethernet broadcast and multicast frames and it will stop after
creating 1000 *.cap files.

In order to specify "unlimited" number of files, use "-n 0" option, but
beware - the free disk space can be occupied by *.cap files and the
system may become unstable.

The URL above has the complete syntax for the filtering expression. If
you need to capture all packets, use: -f " " Blank filter means every
packet will be taken into account.


Using Ethereal to Analyze *.cap files
=====================================

Once the peak traffic is captured into one or several *.cap files, they
can be opened by Ethereal - a network protocol analyzer, available at
http://www.ethereal.com. Ethereal has to be downloaded and installed
separately and it also requires WinPcap packet capture driver (Ethereal
0.10.0 works ok with WinPcap 3.1 beta).

To open *.cap file:

 - start Ethereal;
 - go to File / Open menu, select the file, open it;
 - once the file is opened, go to View / Options and select "Time of
   day". This way you can see packet's timestamp using absolute time. 


Conducting Cisco Recommended Tests
==================================

After you become familiar with general guidelines of how to use nptcap
tool, please conduct these tests to identify specific network problems,
which are harmful to 7905/7912 IP Phones and ATA 186/188 Analog
Telephone Adaptors.


Test 1. Identify heavy multicast, broadcast traffic and erratic unicast
traffic with destination MAC address of a  particular IP Phone or ATA
with voice quality issues (let's assume the troublesome IP Phone has
this MAC address: 00:0b:be:3b:9e:97).

Run nptcap with the following parameters:

nptcap -f "ether broadcast or ether multicast or ether dst 00:0b:be:3b:9e:97"


Test 2. Identify heavy traffic (over 4 Mbps) of all kinds.

Run nptcap with the following parameters:

nptcap -b 4000 -f " "


For both tests, nptcap needs to run until it captures at least a few
peak traffic occurrences. Once the results are captured (can tell by the
nptcap trace messages), the program can be stopped by Ctrl-C and the
*.cap files may be opened with Ethereal for the analysis.

You need to look at the prevailing protocols and source addresses to
recognize the source of heavy traffic. Once identified, the device/
software generating excessive traffic needs to be reconfigured, isolated
to a separate network or taken offline.


=====
