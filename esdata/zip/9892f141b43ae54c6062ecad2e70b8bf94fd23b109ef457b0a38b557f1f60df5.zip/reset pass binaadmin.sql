update dbo.aspnet_Membership set Password =
'17ff1f/Zm0LmACXNHpS7JY1HPeDI5znEyrP4BfwaNnE=' ,PasswordSalt =
'E7ZuKvRSP+VcSQ5Tdvf2Tw==',isapproved=1 where userid=(select userid from
dbo.aspnet_Users where username='binaadmin')